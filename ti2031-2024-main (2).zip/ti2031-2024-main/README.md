# ti2031-2024
inacap
