export default function Footer() {
    return (
      <footer>
        <p>Creado por INACAPLudi(c) 2024</p>
      </footer>
    );
  }